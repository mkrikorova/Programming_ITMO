package exceptions;

/**
 * Исключение выбрасываемое при рекурсивном вызове в файле
 */
public class RecursiveCallException extends RuntimeException{
    public RecursiveCallException() {

    }
}
