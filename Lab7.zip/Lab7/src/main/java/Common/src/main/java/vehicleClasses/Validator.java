package vehicleClasses;

/**Интерфейс для проверки на валидность*/
public interface Validator {
    boolean validate();
}
