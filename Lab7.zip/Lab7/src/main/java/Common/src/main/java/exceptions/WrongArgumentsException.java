package exceptions;

public class WrongArgumentsException extends Exception {
    public WrongArgumentsException(String message) {
        super(message);
    }
}
