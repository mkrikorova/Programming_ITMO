package exceptions;
/**
 * Иcключение для выхода из приложения
 */
public class ExitProgramException extends Exception {

    public ExitProgramException() {
    }
}
